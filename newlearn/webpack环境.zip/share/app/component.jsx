import React from 'react';
import Style from './style/style.css';

export default

class Hello extends React.Component {



    aaa() {
        //
    }

    render() {
        return <h1 className="title1">Hello world</h1>;
    }
}
